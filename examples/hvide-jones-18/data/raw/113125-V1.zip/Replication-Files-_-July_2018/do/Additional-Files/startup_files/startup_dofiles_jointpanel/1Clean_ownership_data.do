/*  This file prepares ownership files delivered by Visma in August 2009.

input: tarik_eiere_sluttfile_ny, tarik_firma_sluttfile_ny, accounting files rskap0713_sel_`t', Foretaksinfo
output: owners */

*****************************
** 0. DB first year *********
*****************************
/* This file records when a company started existing in DB database

Update 05.09.13.  */

clear
global prepared /home1/hans/Eship/DNewVersion/Prepared
global db /home1/hans/data/db

cd $db

global start 1992
global stop 2014

* yearly list of orgnr
forvalues t=$start/$stop {
use orgnr aar sumeiend aarsrs gjeld ak using rskap0713_sel_`t'.dta, clear
count
drop if sumeiend==0 & aarsrs==0 & gjeld==0		/* drop those that have minimal activity */
count
keep orgnr aar ak
duplicates drop orgnr, force
sort orgnr aar
save orgnrlist_`t', replace
}

clear all
forvalues t=$start/$stop {
append using orgnrlist_`t'
}

bys orgnr: egen DB_first_yr=min(aar)
bys orgnr: egen DB_last_yr=max(aar)

count if DB_first_yr==.

keep if aar==DB_first_yr
sort orgnr aar
merge orgnr aar using Foretaksinfo_0616.dta, nokeep keep(selskf etableri stiftaar regdato)
tab _merge
drop _merge

tostring regdato, replace
gen reg_yr_DB=substr(regdato,1,4)
tostring etableri, replace
gen etabl_yr_DB=substr(etableri,1,4)
rename stiftaar stiftaar_DB
destring stiftaar_DB reg_yr_DB etabl_yr_DB, replace

keep orgnr DB_first_yr DB_last_yr stiftaar_DB reg_yr_DB etabl_yr_DB ak selskf
duplicates drop orgnr, force
compress
sort orgnr
saveold $prepared/DB_first_yr.dta, replace

**********************
*** I. Firm file *****
**********************
use tarik_firma_sluttfil_ny, clear
count 		/* there are no duplicates in this file, shd be about 186K  */

order lopenr_firma

rename VAR8 Stiftelsesaar
rename VAR16 niva				/* 0=basisuttrekk, 1=eier niv報 etc, 99=historiske eiere */
replace Nedlagt="0" if Nedlagt==""
replace Nedlagt="1" if Nedlagt!="0"
tab Nedlagt
replace Status="." if Status==""

tostring Stiftelsesdato, replace
gen yy=substr(Stiftelsesdato,1,4)
gen mm=substr(Stiftelsesdato,5,2)
gen dd=substr(Stiftelsesdato,7,2)

destring yy mm dd, replace
gen S=mdy(mm,dd,yy)
drop Stiftelsesdato
rename S Stiftelsesdato

gen Saar=yy
drop yy mm dd
count if Saar!=Stiftelsesaar & Saar!=. & Stiftelsesaar!=.
count if Saar==Stiftelsesaar & Saar!=. & Stiftelsesaar!=.
count if (Saar==Stiftelsesaar+1)| (Saar==Stiftelsesaar-1) & Saar!=. & Stiftelsesaar!=.

count if Saar==.
count if Stiftelsesaar==.

gen Raar=year(Registreringsdato)

destring lopenr_firma, replace
sort lopenr_firma

save firma, replace

********************
*** II. Cleaning ***
********************
use tarik_eiere_sluttfile_ny, clear

/* check if have all owners */
bys lopenr_firma yr: egen sum_share=sum(share)
count if sum_share==1
count if sum_share<1
count if sum_share>1 & sum_share<.

* merge in Raar and Saar
sort lopenr_firma
merge lopenr_firma using firma, nokeep keep(Stiftelsesaar Raar Registreringsdato Foretaksform niva)  //niva==0 for sample firms. All these are AS-er. 
tab _merge
drop _merge

destring pid lopenr_firma, replace

rename lopenr_firma orgnr  //link
rename lopenr_firma_eier orgnr_eier  //link

** import faar (=DB_first_yr) and ak
count
sort orgnr
merge orgnr using DB_first_yr.dta, nokeep keep(DB_first_yr ak DB_last_yr)
tab _merge
drop _merge
rename DB_first_yr faar		/* DB_first_yr is per def the same as faar */

** Visma_first_yr
bys orgnr: egen Visma_first_yr=min(yr)
count if Visma_first_yr==.

** drop if missing orgnr. These did not find match in linkfile (should be close to none)
drop if orgnr==.

** drop if missing faar. These are firms that never pop up in accounting panel
drop if faar==.

** fix sumaksje
rename ak sumaksje
replace sumaksje=100 if sumaksje==0
replace sumaksje=sumaksje*1000        /* Make consistent with SamleFilTest */
gen logsumaksje=ln(sumaksje)

sort orgnr yr
saveold $prepared/owners, replace  //one row per owner-year, includes both person firm and unknown owners

*************************
**  III. More cleaning **
*************************
** add up multiple rows for individuals
duplicates tag orgnr pid yr if status_eier==2 & pid!=., gen(dupl_person)
tab dupl_person
bys orgnr pid yr: egen s=sum(share) if dupl_person==1
sum s
replace share=s if dupl_person==1
sort orgnr pid yr
bys orgnr yr pid: gen row=_n
drop if row==1 & dupl_person==1
drop row s

** add up multiple rows for firms
duplicates tag orgnr orgnr_eier yr if status_eier==1 & orgnr_eier!=., gen(dupl_firm)
tab dupl_firm
bys orgnr pid yr: egen s=sum(share) if dupl_firm==1
sum s
replace share=s if dupl_firm==1
sort orgnr pid yr
bys orgnr yr pid: gen row=_n
drop if row==1 & dupl_firm==1
drop row s

replace share=share/sum_share if sum_share>1  //NB: in some previous version we used "... if sum_share>.9". This meant that we kept MORE 50%+ owners
bys orgnr yr: egen sum_share_temp=sum(share)
sum share,d

saveold temp, replace

****************************************
*** IV. Fillin code for person owners **
****************************************
use temp if status_eier==2, clear
drop if pid==.
bys orgnr yr: gen number_of_owners=_N

sort orgnr pid
by orgnr pid: egen min_year=min(yr)
by orgnr pid: egen max_year=max(yr)
by orgnr pid: egen n_years=count(yr)
gen n_years_target=max_year-min_year+1

gen diff_n_year_target_vs_n_years = n_years_target-n_years

tab n_years_target n_years
tab diff_n_year_target_vs_n_years

sort orgnr pid yr
by orgnr pid: gen gap_size=yr-yr[_n-1]
recode gap_size .=0
by orgnr pid: egen max_gap_size=max(gap_size)

sort orgnr pid yr
*list orgnr pid yr min_year max_year n_years n_years_target gap_size share sum_share if diff_n_year_target_vs_n_years>0

* Expand database
count
expand gap_size, gen(counter)

** fill in share==. for expanded obs
replace share=. if counter==1

*bysort orgnr pid yr counter: gen 
count
gsort orgnr pid yr -counter
save check_person, replace

/*******************************************************************/
/* Substitution rules: substitute with last year of data available */
/*******************************************************************/
use check_person, clear			
replace yr = yr[_n-1] + 1 if counter==1
display "now treshold is 1-sum_share"
sum sum_share_temp,d
gsort orgnr pid yr -counter
gen r=1-sum_share_temp
replace share = share[_n-1] if counter==1 & (r>=share[_n-1])  //what is filled in is less than what remains for sum_share to equal 1
//after appending temp_firm we change some of these changes back again to "."

replace status_eier=2
saveold temp_person, replace

**********************************
*** Fillin code for firm owners **
**********************************
use temp if status_eier==1, clear
drop if orgnr_eier==.
bys orgnr yr: gen number_of_owners=_N

sort orgnr orgnr_eier
by orgnr orgnr_eier: egen min_year=min(yr)
by orgnr orgnr_eier: egen max_year=max(yr)
by orgnr orgnr_eier: egen n_years=count(yr)
gen n_years_target=max_year-min_year+1

gen diff_n_year_target_vs_n_years = n_years_target-n_years

tab n_years_target n_years
tab diff_n_year_target_vs_n_years

sort orgnr orgnr_eier yr
by orgnr orgnr_eier: gen gap_size=yr-yr[_n-1]
recode gap_size .=0
by orgnr orgnr_eier: egen max_gap_size=max(gap_size)

sort orgnr orgnr_eier yr
*list orgnr orgnr_eier yr min_year max_year n_years n_years_target gap_size share sum_share if diff_n_year_target_vs_n_years>0

* Expand database
count
expand gap_size, gen(counter)
*bysort orgnr orgnr_eier yr counter: gen 

** fill in share==. for expanded obs
replace share=. if counter==1

count
gsort orgnr orgnr_eier yr -counter
saveold check_firm, replace

*list orgnr orgnr_eier yr min_year max_year n_years n_years_target gap_size counter share sum_share if diff_n_year_target_vs_n_years>0

/**************************************************************************/
/* Substitution rules: always substitute with last year of data available */
/**************************************************************************/

use check_firm, clear			
replace yr = yr[_n-1] + 1 if counter==1
display "now treshold is 1-sum_share"
sum sum_share_temp,d
gsort orgnr orgnr_eier yr -counter
gen r=1-sum_share_temp
replace share = share[_n-1] if counter==1 & (r>=share[_n-1])  //what is filled in is less than what remains for sum_share to equal 1
// change some of these changes back again if the new sum_share>1.
replace status_eier=1
saveold temp_firm, replace

**************************************
** 4. Appending and some final fix ***
**************************************
use if status_eier==0 using temp, clear
append using temp_person
append using temp_firm
compress

bys orgnr yr: egen sum_share_after_fill=sum(share)
sum sum_share_after_fill,d
display _newline(4)"number of puzzling >1, AFTER fillin"
count if sum_share_after_fill>1
sum sum_share_after_fill if sum_share_after_fill>1
replace share=share/sum_share_after_fill if sum_share_after_fill>1 & sum_share_after_fill<1.05

** not replace for these firms/persons
gen m=1 if sum_share_after_fill>=1.05
replace share=. if sum_share_after_fill>=1.05 & counter==1

sort orgnr yr pid
bys orgnr: egen marker=max(m)
tab marker, missing
display _newline(4)"count number of firms where we could not substitute after all"
count if yr==Visma_first_yr & marker==1

sort orgnr pid yr
bys orgnr yr: gen number_of_owners_new=_N
tab number_of_owners number_of_owners_new

gen l=1 if share>=.1
bys orgnr yr: egen ll=count(l)
bys orgnr yr: egen antstkorr=max(ll)
drop l ll

bys orgnr yr: egen sum_share_new=sum(share)
sum sum_share*

erase temp.dta
erase temp_person.dta
erase temp_firm.dta

** rename and keep
rename orgnr stiftetorgnr
drop lopenr* kilde eierandel DB_last_yr
order stiftetorgnr yr pid share sum_share*

** save into all directories where use the file (a bit awkward but makes modifying other do-files easier)
sort stiftetorgnr yr
saveold $visma/owners, replace  //one row per owner-year, includes both person firm and unknown owners

saveold /home1/hans/Eship/DNewVersion/Prepared/owners, replace
