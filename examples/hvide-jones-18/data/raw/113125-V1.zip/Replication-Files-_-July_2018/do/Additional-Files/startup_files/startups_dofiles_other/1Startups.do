/* This file generates list of founder-stiftetorgnr combinations. ALL startups in database are included.

input: JointPanel
output: founders, startups, Firminfo    */

*****************
** Globals ******
*****************
global vars "stiftetorgnr yr stiftaar etableri faar naceSSB nace2 sumaksje employees"
global firm_vars "bankr_yr mors* etableri bransjek_02 bransjet_02 name"
global performance_vars "stiftetorgnr yr faar stiftaar orgnr sumaksje salgsinn sumeiend visma* logsales employees roa naceSSB activeyear firmage survive3"
global root "/home1/hans/Eship/Scientists"
global prepared "$root/Prepared"

global cut_low "1999" //drop firms that have stiftaar before this
global cut_high "2007" //drop firms that have stiftaar after this
global drop_wealth_management "drop if nace2SSB>64 & nace2SSB<71" //drop financials and real estate as these are likely to be wealth management companies and not real startups
global drop_share .1

global vars_foretak "orgnr aar navn postnr poststed kommnr kommune konkaar mors_orgnr mors_navn mors_eandel regdato etableri ansatte"
global vars_bransje "orgnr aar bransje*"
global startvars "pid stiftetorgnr yr faar stiftaar naceSSB nace2SSB Raar share"

cd $prepared
set niceness 0

********************************
*** 0. Big file with all info **
********************************
use "/home1/hans/Eship/DNewVersion/Prepared/JointPanel.dta", clear

drop I*  // drop dummies since these are generated below

** fill in stiftaar and Raar
foreach v of varlist stiftaar Raar {
bys stiftetorgnr: egen m=max(`v')
replace `v'=m
drop m
}

sort stiftetorgnr pid yr
save big, replace

******************************************************
*** Ia. Define basic sample of founder-stiftetorgnr **
******************************************************
** 1. Define list of founder-stiftetorgnr combinations
use $startvars if yr==faar using big, clear 

** outside time window and finance
drop if stiftaar<$cut_low | stiftaar>$cut_high
$drop_wealth_management
tab stiftaar, m
tab Raar, m

rename naceSSB nace5_startup

keep stiftetorgnr pid share stiftaar Raar nace5_startup  //checked March 2015 that the variable that is renamed here indeed comes from bransjek_02. For some reason bransjek_02 has gotten the name naceSSB in JointPanels.
//ALTERNATIVE rename Raar stiftaar

sort stiftetorgnr pid
saveold founders, replace  //one row per founder-stiftetorgnr

**********************************
** Ib. Basic sample of startups **
**********************************
use founders, clear
keep stiftetorgnr stiftaar
duplicates drop stiftetorgnr, force
sort stiftetorgnr
save startups, replace  //one row per startup

***********************************************
** II. Some help files for performance panel **
***********************************************
** Foretaksinfo
use startups, clear
rename stiftetorgnr orgnr
sort orgnr
joinby orgnr using "/home1/hans/data/db/Foretaksinfo_0713.dta"
keep $vars_foretak
rename aar yr
rename navn name
rename konkaar bankr_yr

duplicates drop orgnr yr, force
compress
sort orgnr yr

saveold Foretaksinfo_startups, replace

** Bransjeinfo
use startups, clear
rename stiftetorgnr orgnr
sort orgnr
joinby orgnr using "/home1/hans/data/db/Bransjeinfo_0713.dta"
keep $vars_bransje
rename aar yr

duplicates drop orgnr yr, force
compress
sort orgnr yr

saveold Bransjeinfo_startups, replace

** Together
use Foretaksinfo_startups, clear
sort orgnr yr
merge orgnr yr using Bransjeinfo_startups
tab _merge
drop _merge

sort orgnr yr
saveold Firminfo, replace





