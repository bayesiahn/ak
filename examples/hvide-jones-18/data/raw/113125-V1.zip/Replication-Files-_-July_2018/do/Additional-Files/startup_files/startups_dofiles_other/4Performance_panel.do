/* This file prepares performance panel.

input: founders
output: performance_panel, performance_panel_prepared  */

clear all

*****************
** Globals ******
*****************
global root "/home1/hans/Eship/Scientists"
global prepared "$root/Prepared"
global cut_low "2000"
global cut_high "2007"

global firm_vars "bankr_yr mors* bransjek_02 bransjet_02 name"

global loop "9" //this is the number of treated + control groups, should equal the $loop in worker do-file. Norway as a whole has $loop+1.
global inds "pid share sex-n_children"  //individual variables not needed in performance file

cd $prepared
set niceness 0

***************************
*** I. Performance panel **
***************************

** 1. Take list of founders-stiftetorgnr and get all data
use founders, clear
joinby stiftetorgnr pid using big

** 2. Drop individual variables we do not need
drop $inds

** 3. one row per startup-year
duplicates drop stiftetorgnr yr, force

** 4. new definition of activeyear. old (based on sufficient sales) does not work that well because relatively high fraction of firms are hi-tech and do not generate sales fast
drop activeyear
gen activeyear=0
replace activeyear=1 if roa!=.
replace activeyear=1 if yr==faar  //do we want to keep this?

** 5. get info from foretaksfil
rename stiftetorgnr orgnr  //orgnr is now orgnr of startup
format %12.0g orgnr
sort orgnr yr
merge orgnr yr using "$root/Prepared/Firminfo", nokeep keep($firm_vars)  //etableri, bransjekoder
tab _merge
drop _merge
rename orgnr stiftetorgnr
** replace bransjek_02=0 if bransjek_02==. & yr!=faar  //NBNBNNB
gen nace2=int(bransjek_02/1000)
gen nace5=bransjek_02

gen bankr=bankr_yr>0
gen b=0

** 6a. tech dummies
gen x=naceSSB
drop nace*
rename x naceSSB
gen nace2SSB=int(naceSSB/1000)

gen l=nace2SSB if yr==faar
bys stiftetorgnr: egen ll=max(l)
gen nace2SSB_orig=ll
drop l ll

gen l=naceSSB if yr==faar
bys stiftetorgnr: egen ll=max(l)
gen naceSSB_orig=ll
drop l ll

** Definitions
gen n5= naceSSB_orig
gen n4=int(n5/10)
gen n3=int(n5/100)
gen n2=int(n5/1000)

** hi tech
gen hi_tech=(n3==244|n2==30|n2==32|n2==33|n3==353)

** medium to high tech
gen medium_hi_tech=(n2==29|n2==31|n2==34)
replace medium_hi_tech=1 if n2==24 & n3!=244
replace medium_hi_tech=1 if n2==35 & n3!=351 & n3!=353

** medium to low tech. NB here we add oil and gas nace 11!!!!
gen medium_lo_tech=(n3>=23&n3<=28) & n3!=24 //nace==11, oil and gas, 23 coke refined petroleum,  24 chemicals, 27 metals, 28 mechanical, 29 machinery, 30 office equip and computers, 31 electrical, 32 radio television communication, 33 medical instruments,  34 motor vehicles, 72 IT
replace medium_lo_tech=1 if n2==11

** hi_tech knowledge intensive
replace hi_tech=1 if n2==64|n2==72|n2==73

/* DROP hi knowledge intensive industries
gen kis=(n2>=61&n2<=67) & n2!= 63
replace kis=1 if n2==62|n2==64 */

** low tech
gen lo_tech=0
replace lo_tech=1 if hi_tech==0 & medium_hi_tech==0 & medium_lo_tech==0

** broad tech category
gen tech=0
replace tech=1 if lo_tech==0

** broad tech without IT
gen tech_noIT=tech
replace tech_noIT=0 if n2==72

drop n2 n3 n4 n5

tab hi_tech
tab tech
tab tech_noIT

** 6b. Time constant logsumaksje
drop logsumaksje*
gen u=sumaksje if yr==faar
bys stiftetorgnr: egen uu=max(u)
replace sumaksje=uu
gen logsumaksje=ln(sumaksje)
gen logsumaksjesq=logsumaksje^2
drop u uu

** 7. various panel variables
sort stiftetorgnr yr
gen after=stiftaar>=2003
gen logansatt=ln(employees+1)
gen leiendeler=log(sumeiend+10)

** time, sector, firmage and dummies
xi i.firmage, noomit
renpfix _I If
xi i.yr, noomit
renpfix _I I

compress
order stiftetorgnr yr stiftaar faar
sort stiftetorgnr yr
save performance_panel, replace

*******************************************************************************************************
** II. Performance_panel_prepared: Get sample variable and create one row per sample-stiftetorgnr-yr **
*******************************************************************************************************

*** All startups in economy
use stiftetorgnr using founders, clear  //one row per stiftetorgnr-founder
local c=$loop+1
gen sample=`c'
keep stiftetorgnr sample
save startups_all, replace

** List of startups-sample combinations we want to follow
use startups_all, clear
forvalues v=0/$loop {  //$loop + 1
append using startups_workergroup_`v'
replace sample=`v' if sample==.
}

keep stiftetorgnr sample
drop if sample==.
duplicates drop stiftetorgnr sample, force
sort stiftetorgnr sample
saveold performance_list, replace

** Prepare performance file
use performance_list, clear
joinby stiftetorgnr using performance_panel
drop if stiftaar<$cut_low | stiftaar>$cut_high  //drop startups with stiftaar prior to 2000

** use first-year nace codes
xi i.nace2SSB_orig, noomit
renpfix _In In

tab sample, m

gen treated=sample==0
drop after
gen after=stiftaar>=2003
gen after_treated=after*treated

tab hi_tech
tab lo_tech

* prepare aggregate variables
local list5="salgsinn sumeiend employees"
foreach v of local list5 {
gen `v'_agg=`v'
* replace `v'_agg=0 if `v'==. & activeyear==0  //alternative
replace `v'_agg=0 if `v'==. |`v'<0
}

gen logansatt_agg=ln(employees_agg+1)
gen logsales_agg=ln(salgsinn_agg+10)
gen leiendeler_agg=ln(sumeiend_agg+10)
gen logemployees_agg=ln(employees_agg+1)
gen logassets_agg=ln(sumeiend+10)

gen logemployees=logansatt
gen logassets=leiendeler

saveold performance_panel_prepared_fixed, replace
