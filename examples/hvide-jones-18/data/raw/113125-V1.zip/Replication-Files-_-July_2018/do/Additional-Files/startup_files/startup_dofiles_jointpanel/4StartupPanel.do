/* This file generates StartupPanel.dta.

Input: Bransjeinfo, Foretaksinfo, rskap0713_sel_`t', adssb't', stiftetorgnrlistE
Output: StartupPanel */

global prepared /home1/hans/Eship/DNewVersion/Prepared
cd $prepared

****************
** Locals ******
****************
local start="1999"
local end="2014"  //DB data for 2014 ready fall 2016
local startvar="stiftetorgnr pid faar sumaksje share Visma_first_yr Stiftelsesaar Raar"

***************************************
** I. Yearly files with firm info *****
***************************************
forvalues t=`start'/`end' {
use `startvar' using stiftetorgnrlistE, clear
rename stiftetorgnr orgnr
gen aar=`t'

sort orgnr aar
merge orgnr aar using "/home1/hans/data/db/Bransjeinfo_0616.dta", nokeep keep(bransjek_02) update replace
rename bransjek_02 nace5
tab _merge
drop _merge

* merge in firm info
sort orgnr aar
merge orgnr aar using "/home1/hans/data/db/Foretaksinfo_0616.dta", nokeep keep(konkaar* postnr stiftaar selskf) update replace
tab _merge
drop _merge 

* merge in accounting data
sort orgnr
merge orgnr using "/home1/hans/data/db/rskap0713_sel_`t'.dta", nokeep keep(gjeld ebitda sumeiend salgsinn aarsrs utb kgjeld lgjeld ek driftsrs rentekost)
tab _merge
drop _merge

* drop superfluous rows (shd be zero)
rename aar yr
keep if yr==`t'
duplicates drop orgnr, force

* create roa
gen ss=sumeiend
replace sumeiend=10 if sumeiend>=0&sumeiend<=10
gen roa=ebitda/sumeiend
replace roa=. if sumeiend<0
drop ss

* adjustments and logvariables
replace sumaksje=50 if sumaksje<0  //fix 1 observation. Remember that sumaksje=ak
gen logsales=ln(salgsin+10)
gen gjeldsgrad=gjeld/sumeiend

* winsorize roa (do we want to use assets from year before?!?)
winsor roa, gen(a) p(0.05)
replace roa=a
drop a

* winsorize aarsrs
winsor aarsrs, gen(a) p(0.05)
replace aarsrs=a
drop a

* logsumaksje
gen logsumaksje=ln(sumaksje+10)

* firmage
gen firmage=yr-faar

* activeyear
gen activeyear=.
replace activeyear=1 if aarsrs!=.
replace activeyear=0 if aarsrs==.
replace activeyear=0 if salgsinn<50 & yr!=faar   /* Demand at least NOK 50K in sales except for first year to be defined as active */
replace activeyear=. if yr<faar			/* Activeyear==. if yr<faar */
tab activeyear

* sole owner
gen sole=0
replace sole=1 if share==1

* Tabulate in nace code and dummies
replace nace5=0 if nace5==. & activeyear==1

rename nace5 naceSSB
gen nace2SSB=int(naceSSB/1000)

duplicates drop orgnr, force
rename orgnr stiftetorgnr
sort stiftetorgnr
saveold ForetaksInfo`t'.dta, replace
}

***********************
** II. Panel file *****
***********************
clear
set obs 1
forvalues t=`start'/`end' {
append using ForetaksInfo`t'
erase ForetaksInfo`t'.dta
}
bys yr: count		//number of observations per year, shd be constant

* drop years before entry
*drop if yr<faar
drop if stiftetorgnr==.
sort stiftetorgnr yr

* survive
forvalues t=0/13 {
gen survive`t'=.
}
forvalues t=0/13 {
replace survive`t'=1 if yr==faar+`t' &activeyear==1
}
forvalues t=0/13 {
replace survive`t'=0 if yr==faar+`t' &activeyear==0
}

forvalues t=0/13 {
bys stiftetorgnr: egen su=max(survive`t')
replace survive`t'=su
drop su
}

local vars "sumeiend activeyear salgsinn employees aarsrs roa"
local time="0 2 4 6"
foreach v of local vars {
foreach t of local time {
gen `v'_`t'=`v' if yr==faar+`t'
bys stiftetorgnr: egen m=max(`v'_`t')
replace `v'_`t'=m
drop m
}
}

compress
sort pid yr
saveold StartupPanel, replace

sum if yr==faar

count if stiftaar==Stiftelsesaar & yr==faar
count if stiftaar!=Stiftelsesaar & yr==faar

