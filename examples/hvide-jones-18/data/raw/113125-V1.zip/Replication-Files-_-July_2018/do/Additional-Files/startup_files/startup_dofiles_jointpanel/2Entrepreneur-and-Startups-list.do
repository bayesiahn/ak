/* List of entrepreneurs and startups

Input: owners
Output: stiftetorgnrlistE, pidlistE */

clear
global prepared /home1/hans/Eship/DNewVersion/Prepared


cd $prepared

********************
** 0. Locals *******
********************
local list="stiftetorgnr pid share faar sumaksje Stiftelsesaar Raar antstkorr"
local cut="1999"	//drop if faar<cut from Visma files

****************************
*** I. Selecting startups **
****************************
use owners, clear    // Panel with ownership data for all firms in Visma [including non-startups]. Based on PrepareVismaFiles.do 
keep if yr==Visma_first_yr

** drop if not niva==0, i.e., not part of basic sampling. All niva==0 are AS-er established in 1999->
keep if niva==0
tab Foretaksform, m
drop niva Foretaksform  //all are niva==0, Foretaksform==AS and Raar>=1999 (a handful has Raar earlier than that, drop these)
tab Raar, m
drop if Raar<1999

* drop blank ID observations and non-person Id
drop if stiftetorgnr==.
drop if pid==.
drop if pid==0
drop if share==.

* now left with person owners

* Recall faar===DB_first_yr. Drop firms that are started up prior to `cut'.	THIS IN ORDER TO GET RID OF FIRMS THAT WE DO NOT HAVE OWNERSHIP DATA FOR IN THE BEGINNING.
drop if faar<`cut'
count
count if faar==.
tab faar

*rename lopenr_firma_eier lopenr_firma

keep `list' Visma_first_yr
order `list'

* multiple startup events
duplicates tag pid, gen(no)
replace no=no+1
tab no

compress
sort pid
saveold stiftetorgnrlistE, replace		//one row per founded company.  50%+ owner included
display "number of startups where one person founder has more than 50%"
count

****************************
** II. Sample of founders **
****************************
use stiftetorgnrlistE, clear

duplicates drop pid, force

keep pid
sort pid
saveold pidlistE, replace

cd $root
