/* This file combines sociodemographic panel for the founders and startup info panel for their firms to create JointPanel.dta.

input: SocioPanel, StartupPanel
output: JointPanel */

global prepared /home1/hans/Eship/DNewVersion/Prepared
cd $prepared

*******************************************
** I. Joinby sociopanel and startuppanel **
*******************************************
use SocioPanel, clear  //NB need to start with this to avoid that pid stays constant!!
sort pid yr
joinby pid yr using StartupPanel, unmatched(both)
tab _merge
count if yr<faar
drop if _merge!=3
drop _merge

drop if yr<faar
sum

* Use avgbefore for yr==faar
local list "brformavgbefore pearnavgbefore logbrformavgbefore logpearnavgbefore"
foreach v of local list {
replace `v'=. if yr!=faar
bys stiftetorgnr: egen m=max(`v')
replace `v'=m
drop m
}

*******************************
** II. Create some variables **
*******************************
gen syear=1 if stiftetorgnr==orgnr
replace syear=0 if stiftetorgnr!=orgnr & orgnr!=.
replace syear=. if stiftetorgnr!=orgnr & orgnr==.
tab syear

bys pid stiftetorgnr: egen s=max(syear)
compress
sort pid yr

* dummies
xi i.yr
renpfix _I I
gen nace1=int(nace2SSB/10)
sum nace1
xi i.nace1
renpfix _I I

saveold JointPanel, replace

sum

cd $root
