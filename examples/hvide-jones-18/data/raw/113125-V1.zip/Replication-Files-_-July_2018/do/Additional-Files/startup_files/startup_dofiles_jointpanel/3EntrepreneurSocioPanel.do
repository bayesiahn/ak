/* This file prepares yearly and panel sociodemographics for the entrepreneurs

Input: adssb't', Ligning`t', pidlistE
Output: SocioPanel */

global prepared /home1/hans/Eship/DNewVersion/Prepared
cd $prepared

****************************
** 0. Locals and globals  **
****************************
global data_filip "/data/wagedta"
local socio="age sex pearn hrs unempm plant org yr eduy occ mstat komres komarb edut*"
local wealth="brform brin wkapin rentutg gjeld"
local start="1986"
local end="2010"

*************************************
** I. Yearly Sociodemographic files * 
*************************************
/* Demographic data in "stifterDemographics`t'" and income/wealth data in "StifterIncomeWealth`t'" */

* Yearly files for SSB data
forvalues t=`start'/`end' {
use pid `socio' using ${REG_DIR}adssb`t', clear
sort pid
merge pid using pidlistE
tab _merge
drop if _merge==1
drop _merge
replace yr=`t'
sort pid
destring pid, replace

duplicates drop pid, force
sort pid
save StifterDemographics`t', replace
}

* Yearly files for income/wealth data
forvalues t=1993/2006 {
use pidlistE, clear
merge pid using "/home1/hans/data/inntdta/Ligning`t'.dta", nokeep keep(`wealth')
tab _merge
drop _merge
rename gjeld pgjeld
*duplicates drop pid, force  //superfluous
sort pid
saveold StifterIncomeWealth`t', replace
}		


forvalues t=`start'/1992 {
use StifterDemographics`t', clear
sort pid
saveold Stifter`t', replace
erase StifterDemographics`t'.dta
}

forvalues t=1993/2006 {
use pidlistE, clear
merge pid using StifterDemographics`t', update
tab _merge
drop _merge
sort pid
merge pid using StifterIncomeWealth`t', update
tab _merge
drop _merge
sort pid
saveold Stifter`t', replace
erase StifterDemographics`t'.dta
erase StifterIncomeWealth`t'.dta
}

forvalues t=2007/`end' {
use StifterDemographics`t', clear
sort pid
saveold Stifter`t', replace
erase StifterDemographics`t'.dta
}

********************************
** II. Create panel ************
********************************
clear
set obs 1
forvalues t=`start'/2014 {
append using Stifter`t'
erase Stifter`t'.dta
}

drop if pid==.
sort pid yr

* 2. Fix education
sort pid yr
bysort pid: replace eduy=eduy[_n-1] if eduy==.
sort pid yr

gsort pid -yr
bysort pid: replace eduy=eduy[_n-1] if eduy==.
gsort pid -yr

replace eduy=9 if eduy==0 | eduy==.

* 3. Fix gender
bys pid: egen ss=max(sex)
replace sex=ss
drop ss
replace sex=1 if sex==.			// assume male if missing

* 4. Fix age
sort pid yr
bysort pid: replace age=age[_n-1]+1 if age==.
gsort pid -yr
bysort pid: replace age=age[_n-1]-1 if age==.
gen agesq=age^2

* 5. Pearn
replace pearn=brin-wkapin if pearn==.

* 7. Avgbefore, including self-employed and hrs experience. NB: do NOT count current year (the second 0 in window parenthesis)
sort pid yr
tsset pid yr
tssmooth ma pearnavgbefore=pearn, window(5 0 0)
sort pid yr
tssmooth ma brformavgbefore=brform, window(5 0 0)

gen logpearnavgbefore=ln(10000 + pearnavgbefore)
gen logbrformavgbefore=ln(10000 + brformavgbefore)

gen se=1 if occ==1|occ==2
replace se=0 if occ==3|occ==4

sort pid yr
tssmooth ma se_exp10=se, window(10 0 0)
tssmooth ma hrs_exp10=hrs, window(10 0 0)
gen fulltime=hrs==3
replace fulltime=. if hrs==.
gen orgnr_missing=(orgnr==.)

sort pid yr
bys pid: gen fulltime_lag=fulltime[_n-1]
bys pid: gen orgnr_missing_lag=orgnr_missing[_n-1]

* 8. marital dummy
gen single=mstat==1
replace single=. if mstat==.

tab mstat
tab single

drop if yr<1992
compress
sort pid yr
save SocioPanel, replace

bys dd: sum if yr==2000
duplicates drop pid, force
tab dd

cd $root
