************************************************************
* Replication code: individual patent/NIFU level to aggregate level
* Redacted codebook for the master patent/NIFU data is provided in replication folder.
************************************************************

clear
set more off

************************
* Norwegian patent data is merged with NIFU data at NIFU facility.
* Product is the master patent data set, at the patent-inventor level, with indicators for whether patent had
* inventor who was a university employee.
* treated = 1 if patent has inventor was employed at university in year of patent application
* treated_balanced = 1 if patent has inventor who was employed at university throughout sample period
* treated_preindiv = 1 if patent has inventor who was employed at university in 2001 (i.e. prior to policy change)

use ..\data\all_patents_known_8_15_treat_status, clear

* Condense to patent level
bys patentnr:  keep if _n==1
save ..\data\all_patents_known_8_15_treat_status_patent_level, replace

*********************************************************************
* Build aggregate counts for each treated variable, uni vs non uni

foreach TREATED of varlist treated* {
	
	use ..\data\all_patents_known_8_15_treat_status_patent_level, clear

	* Condense to appyr by treated counts, for aggregate analysis
	bys appyr `TREATED': g patents = _N
	bys appyr `TREATED': egen inventors = sum(inventorcount)
	bys appyr `TREATED': keep if _n==1
	g logpatents = log(patents)
	sort appyr `TREATED'
	save ..\data\tempag, replace
	
	* Merge in workforce measures
	use yr n_workers pop using ..\data\workforce, clear
	g `TREATED'=0
	replace `TREATED'=1 if pop=="University Phd"
	ren yr appyr
	sort appyr `TREATED'
	merge 1:1 appyr `TREATED' using ..\data\tempag
	drop _merge

	*** Get per capita counts
	bys appyr: g t1 = n_workers if pop=="University Phd"
	bys appyr: egen uniworkforce = max(t1)
	drop t1
	bys appyr: g t1 = n_workers if pop=="Norway"
	bys appyr: egen norwayworkforce = max(t1)
	drop t1
	g nonuniworkforce = norwayworkforce - uniworkforce

	g patents_pc = patents / uniworkforce if `TREATED'==1
	replace patents_pc = patents / nonuniworkforce if `TREATED'==0
	g logpatents_pc = log(patents_pc)
	
	g inventors_pc = inventors / uniworkforce if `TREATED'==1
	replace inventors_pc = inventors / nonuniworkforce if `TREATED'==0
	g loginventors_pc = log(inventors_pc)
	
	** Get treated*post
	xi i.appyr
	g post=0
	replace post=1 if appyr>=2003
	g `TREATED'_post = `TREATED'*post

	save ..\data\aggcount_`TREATED', replace
}

**********************************************************
* Clean aggregate files and save for public replication analysis

* Main sample
use ..\data\aggcount_treated, clear
keep appyr treated patents logpatents patents_pc logpatents_pc loginventors_pc _I* treated_post
save ..\data\aggcount_patents, replace
erase ..\data\aggcount_treated.dta

* Balanced
use ..\data\aggcount_treated_balanced, clear
keep appyr treated_balanced logpatents _I* treated_balanced_post
ren treated_balanced treated
ren treated_balanced_post treated_post
save ..\data\aggcount_patents_balanced, replace
erase ..\data\aggcount_treated_balanced.dta

* Pre period individuals
use ..\data\aggcount_treated_preindiv, clear
keep appyr treated_preindiv logpatents _I* treated_preindiv_post
ren treated_preindiv treated
ren treated_preindiv_post treated_post
save ..\data\aggcount_patents_preindiv, replace
erase ..\data\aggcount_treated_preindiv.dta


***********************************************************
* Build technology-level counts
* 1-digit technology level for each treated variable
***********************************************************

************************************************
* Make technology x year scaffold

use ..\data\all_patents_known_8_15_treat_status_patent_level, clear
drop if coarse==""
replace coarse = upper(coarse)
g tech1 = substr(coarseclass,1,1)
bys tech1 appyr:  keep if _n==1
keep tech1 appyr
egen techdum1 = group(tech1)
tsset techdum1 appyr
tsfill, full
count
sort techdum1 appyr
save ..\data\tech1_appyr_scaffold, replace

**********************************************************
* Build tech-year-treated counts panels

use ..\data\all_patents_known_8_15_treat_status_patent_level, clear
foreach TREATED of varlist treated* {	
	display " "
	display "************************************************"
	display "treated is `TREATED'"
	use ..\data\all_patents_known_8_15_treat_status_patent_level, clear

	* tech class type
	drop if coarse==""
	replace coarse = upper(coarse)
	g tech1 = substr(coarseclass,1,1)

	* Condense to appyr by treated counts, for aggregate analysis
	bys tech1 appyr `TREATED': g patents = _N
	bys tech1 appyr `TREATED': egen inventors = sum(inventorcount)
	bys tech1 appyr `TREATED': keep if _n==1
	g logpatents = log(patents)
	keep tech1 appyr treated* patents inventors
	
	* Merge to scaffold and replace 0s
	egen techdum1 = group(tech1)
	save patents_tech1_panel_unbalanced, replace
	keep if `TREATED'==1
	sort techdum1 appyr
	merge 1:1 techdum1 appyr using ..\data\tech1_appyr_scaffold
	replace patents=0 if patents==.
	replace inventors=0 if inventors==.
	replace `TREATED'=1 if `TREATED'==.
	drop _merge
	save patents_tech1_panel_treated, replace
	
	use patents_tech1_panel_unbalanced, clear
	keep if `TREATED'==0
	sort techdum1 appyr
	merge 1:1 techdum1 appyr using ..\data\tech1_appyr_scaffold
	replace patents=0 if patents==.
	replace inventors=0 if inventors==.
	replace `TREATED'=0 if `TREATED'==.
	drop _merge
	
	append using patents_tech1_panel_treated
	sort appyr `TREATED'
	save patents_tech1_panel_balanced, replace
	
	* Get log counts
	g logpatents = log(patents)
	g loginventors = log(inventors)
	*g logp1 = log(patents + 1)
	*g logi1 = log(inventors + 1)
	
		* merge in workforce measures
	sort appyr `TREATED'
	save ..\data\tempag, replace
	use yr n_workers pop using ..\data\workforce, clear
	g `TREATED'=0
	replace `TREATED'=1 if pop=="University Phd"
	ren yr appyr
	sort appyr `TREATED'
	merge 1:n appyr `TREATED' using ..\data\tempag
	drop _merge

	*** Get per capita counts
	bys appyr: g t1 = n_workers if pop=="University Phd"
	bys appyr: egen uniworkforce = max(t1)
	drop t1
	bys appyr: g t1 = n_workers if pop=="Norway"
	bys appyr: egen norwayworkforce = max(t1)
	drop t1
	g nonuniworkforce = norwayworkforce - uniworkforce

	g patents_pc = patents / uniworkforce if `TREATED'==1
	replace patents_pc = patents / nonuniworkforce if `TREATED'==0
	g logpatents_pc = log(patents_pc)
	
	g inventors_pc = inventors / uniworkforce if `TREATED'==1
	replace inventors_pc = inventors / nonuniworkforce if `TREATED'==0
	g loginventors_pc = log(inventors_pc)
	
	** Get treated*post
	xi i.appyr
	g post=0
	replace post=1 if appyr>=2003
	g `TREATED'_post = `TREATED'*post

	* Get tech1 dummies
	xi i.techdum1, pre(_c)
	save ..\data\aggcount_tech1_`TREATED', replace
}



**********************************************************
* Clean technology class aggregate files and save for public replication analysis

* Main sample
use ..\data\aggcount_tech1_treated, clear
keep appyr treated patents logpatents_pc  techdum1 _I* _ctech* treated_post
save ..\data\aggcount_tech1, replace
erase ..\data\aggcount_tech1_treated.dta

* Pre period individuals
use ..\data\aggcount_tech1_treated_preindiv, clear
keep appyr treated_preindiv patents logpatents_pc  techdum1 _I* _ctech* treated_preindiv_post
ren treated_preindiv treated
ren treated_preindiv_post treated_post
save ..\data\aggcount_tech1_preindiv, replace
erase ..\data\aggcount_tech1_treated_preindiv.dta






