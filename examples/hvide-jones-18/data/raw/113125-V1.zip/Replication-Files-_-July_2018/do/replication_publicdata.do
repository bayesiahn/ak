*******************************************************
* University Innovation and the Professor's Privilege
* Replication Files
*******************************************************

clear
set more off

******************************
* Figure 1
******************************

use ..\data\aggregate_startups, clear

* Fig. 1A 
g start_uni = startups if treated==1
label var start_uni "University"
g start_nonuni = startups if treated==0
label var start_nonuni "Non University"
twoway (line start_uni yr if treated==1, ylab(0(5)30) lcolor(red) lwid(thick) ytitle("University Startups")) (line start_nonuni yr if treated==0, lcolor(blue) lwid(thick) yaxis(2) ylab(0(1000)7000, axis(2)) ytitle("Non-University Startups", axis(2)) ), xlab(2000(1)2007) scheme(s1color) xtitle("Year of Foundation")

* Fig. 1B 
g start_uni_pc = startups_pc if treated==1
label var start_uni_pc "University"
g start_nonuni_pc = startups_pc if treated==0
label var start_nonuni_pc "Non University"
twoway (line start_uni_pc yr if treated==1, ylab(0(.002).008) lcolor(red) lwid(thick) ytitle("University Startups, per Researcher")) (line start_nonuni_pc yr if treated==0, ylab(0(.001).00315, axis(2)) lcolor(blue) lwid(thick) yaxis(2) ytitle("Non-University Startups, per Norwegian Worker", axis(2)) ), xlab(2000(1)2007) scheme(s1color) xtitle("Year of Foundation")


******************************
* Figure 2
******************************

use ..\data\aggcount_patents, clear
keep if appyr>=1995
sort treated appyr

* Fig. 2A
g patuni = patents if treated==1
label var patuni "University"
g patnonuni = patents if treated==0
label var patnonuni "Non University"
twoway (line patuni appyr if treated==1, ylab(0(10)50) lcolor(red) lwid(thick) ytitle("University Patents")) (line patnonuni appyr if treated==0, lcolor(blue) lwid(thick) yaxis(2) ylab(0(100)670, axis(2)) ytitle("Non-University Patents", axis(2)) ), xlab(1995(2)2009) scheme(s1color) xtitle("Year of Patent Application")

* Fig. 2B
g patuni_pc = patents_pc if treated==1
label var patuni_pc "University"
g patnonuni_pc = patents_pc if treated==0
label var patnonuni_pc "Non University"
twoway (line patuni_pc appyr if treated==1, ylab(0(.004).012) lcolor(red) lwid(thick) ytitle("University Patents, per University Researcher")) (line patnonuni_pc appyr if treated==0, ylab(0(.00005).00025, axis(2)) lcolor(blue) lwid(thick) yaxis(2) ytitle("Non-University Patents, per Norwegian worker", axis(2)) ), xlab(1995(2)2009) scheme(s1color) xtitle("Year of Patent Application")


******************************
* Tables 1a, 1b 
* These use administrative data.
******************************

******************************
* Table 1c (Note: gender not disclosed here)
******************************

use ..\data\all_patents_npo, clear

* All Norway patents/inventors
codebook patentnr
codebook name
sum appyr

* Patents applied for while inventor employed at uni
codebook patentnr if unipatent 
codebook uni_inventor_id if unipatent

* For Table 1c notes:  patents from inventors ever employed at universities
codebook patentnr if inventor_ever_uni

* Fraction cited & Fraction also USPTO/EPO/JPO
use ..\data\patent_quality, clear
tab triad_or
tab triad_or if treated
tab cited
tab cited if treated



******************************
* Table 2
******************************

global table "..\tables"

use ..\data\science_yearly_1, clear
eststo clear  //explanation of sample variable: sample==2 means full-time employed not working at a uni, 3=same as 2 but with at least master, same as 3 but Phd, 99=family members
eststo: quietly reg log after* treated if (sample==0|sample==2) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, replace keep(treated after*) addtext(Year FE, NO, Sector FE, NO, Control Sample, Norway, Model, OLS) ctitle(Log Startups) title(Table 2. Startups, Aggregate and Sector Level Analysis) addnote(Columns [1] and [3] consider aggregate counts per year for the treatment and control groups. Columns [2] and [4] consider aggregate counts per worker. In columns [5]-[7], observations are sector x year for the treatment and control groups, with sector determined by the 1-digit NACE code. Robust standard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.1)
eststo: quietly reg ln after* treated if (sample==0|sample==2) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, NO, Sector FE, NO, Control Sample, Norway, Model, OLS) ctitle(Log Startups per Worker) 

eststo: quietly reg log after* treated if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, NO, Sector FE, NO, Control Sample, Ph.D., Model, OLS) ctitle(Log Startups)
eststo: quietly reg ln after* treated if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, NO, Sector FE, NO, Control Sample, Ph.D., Model, OLS) ctitle(Log Startups per Worker)

use ..\data\science_yearly_nace, clear
quietly reg log after_treated treated i.stiftaar i.n1 if (sample==0|sample==2) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, YES, Sector FE, YES, Control Sample, Norway, Model, OLS) ctitle(Log Startups)
quietly poisson n_startups after_treated treated i.stiftaar i.n1 if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, YES, Sector FE, YES, Control Sample, Ph.D. workforce, Model, Poisson) ctitle(Startups)

// col (5) results
use ..\data\science_yearly_pre, clear
eststo: quietly reg log after* treated if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, NO, Sector FE, NO, Control Sample, Phds, Model, OLS) ctitle(Log Startups)

// col (8) results
use ..\data\science_yearly_pre_nace, clear
quietly poisson n_startups after_treated treated i.stiftaar i.n1 if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table2.doc, append keep(treated after*) addtext(Year FE, YES, Sector FE, YES, Control Sample, Ph.D. workforce, Model, Poisson) ctitle(Startups)

erase $table/Table2.txt

******************************
* Tables 3-6
* These use administrative data.
* For .do file, see "replication_admindata.do"
******************************

******************************
* Table 7
******************************

use ..\data\aggcount_patents, clear
reg logpatents treated_post treated _I* if appyr>=1995 & appyr<=2010, robust
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") replace
reg logpatents_pc treated_post treated _I* if appyr>=1995 & appyr<=2010, robust
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg loginventors_pc treated_post treated _I* if appyr>=1995 & appyr<=2010, robust
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

use ..\data\aggcount_patents_balanced, clear
reg logpatents treated_post treated _I* if appyr>=1995 & appyr<=2010, robust
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

use ..\data\aggcount_patents_preindiv, clear
reg logpatents treated_post treated _I* if appyr>=1995 & appyr<=2010, robust
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

use ..\data\aggcount_tech1, clear
poisson patents treated_post treated _I* _c* if appyr>=1995 & appyr<=2010, cluster(techdum1)
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg logpatents_pc treated_post treated _I* _c* if appyr>=1995 & appyr<=2010, cluster(techdum1)
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

use ..\data\aggcount_tech1_preindiv, clear
poisson patents treated_post treated _I* _c* if appyr>=1995 & appyr<=2010, cluster(techdum1)
outreg using ..\tables\Table7, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

******************************
* Table 8
******************************

use ..\data\individual_patents_t8, clear
reg patented treated_post treated post if appyr>=1995, cluster(id_npo)
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") replace
reg patented treated_post treated _Iappyr* if appyr>=1995, cluster(id_npo)
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge
xtreg patented treated_post treated _Iappyr* if appyr>=1995, fe vce(cluster id_npo) 
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge

* rare names
reg patented treated_post treated post if appyr>=1995 & freq==2, cluster(id_npo)
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") title("Individual-Year Level, Dummy for Patenting that Year") note("Standard errors clustered by individual.") merge
reg patented treated_post treated post _Iappyr* if appyr>=1995 & freq==2, cluster(id_npo)
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") title("Individual-Year Level, Dummy for Patenting that Year") note("Standard errors clustered by individual.") merge
xtreg patented treated_post treated post _Iappyr* if appyr>=1995 & freq==2, fe vce(cluster id_npo) 
outreg using ..\tables\Table8, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge


******************************
* Table 9
******************************

use ..\data\individual_patents_t9, clear
xtset
reg patented uni_pre00_02_post uni_pre00_02 post if include_pre==1 & appyr>=1995, cluster(id_npo)
outreg using ..\tables\Table9, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") replace
xtreg patented uni_pre00_02_post uni_pre00_02 post _Iappyr* if include_pre==1 & appyr>=1995, fe vce(cluster id_npo)
outreg using ..\tables\Table9, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge

reg patented stayer_post stayer post if include_stay==1 & appyr>=1995, cluster(id_npo)
outreg using ..\tables\Table9, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge
xtreg patented stayer_post stayer post _Iappyr* if include_stay==1 & appyr>=1995, fe vce(cluster id_npo)
outreg using ..\tables\Table9, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") note("Standard errors clustered by individual.") merge


******************************
* Table 10
******************************

use ..\data\patent_quality, clear
reg cited treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") replace
poisson ncites treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg ncites treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg EPmatch treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg USmatch treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg triad_and treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg triad_or treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
reg inforce treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge
poisson patduration treated_post treated _Iappyr* if appyr>=1995, robust
outreg using ..\tables\Table10, se starloc(1) starlev(10 5 1) summstat(r2\N) summtitle("R2"\"Obs") merge

