
********************************************************
*** University Innovation and Professor's Privilege ****
********************************************************

*****************************************************************
*  This file replicates the main startup results in Tables 3-6,
*  which use administrative data.  
*  For Table 2, see "replication_publicdata.do".
*  Input: worker_panel_fixed, performance_panel_prepared_fixed
*  Output: tables in paper
*****************************************************************

clear all
set matsize 11000
set maxiter 15000

********************
** 0. Globals ******
********************
global vars "stiftetorgnr yr stiftaar etableri faar naceSSB nace2 sumaksje employees"
global firm_vars "bankr_yr mors* etableri bransjek_02 bransjet_02 name"
global root "/home1/hans/Eship/Scientists"
global prepared "$root/Prepared"
global socio "age sex mstat"

global stats_ext "mean sd p50 p75 p90 p95 min max N"
global stats "mean sd p50 p75 p90 N"
global stats_ind "mean sd p50 N"

global cut_low "2000"
global cut_high "2007"
global individual_regressors = "married logbrform logpearn sex"
global keep_variables "pid educ eneur* treated after* I* $individual_regressors stayer"  //keep this in file where run regressions
global table "$root/Tables_replication_Feb_2018"

cd $prepared
set niceness 0
set linesize 255

************************************************
** Table 3. Startups individuals, all workers **
************************************************
use temp2_prepared_fixed, clear

sum eneur*
bys after: sum eneur

quietly reg eneur treated after*, cl(pid)
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table3.doc, replace keep(treated after*) title(Table 3: Startups, Individual Level, All Workers) ctitle(All Workers) addstat(mean dep, `m') addtext(Year FE, NO, Individual FE, NO, Age FE, NO, Years of education FE, NO, Sociodemographic controls, NO) addnote(The dependent variable is an indicator for whether the individual started a company that year.  Estimates are the linear probability model.  Non-linear probability models [Probit or Logit] produce similar results but must be estimated without individual fixed effects.  The individual time-varying controls include lagged marital status, lagged total years of education dummies, log income, and log wealth.  Standard errors are clustered by individual. *** p<0.01, ** p<0.05, * p<0.1.) 

quietly areg eneur treated after_treated Iy*, cl(pid) absorb(pid)  //Individual and time FE
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table3.doc, append keep(treated after*) addtext(Year FE, YES, Individual FE, YES, Age FE, NO, Years of education FE, NO, Sociodemographic controls, NO) ctitle(All Workers) addstat(mean dep, `m')

quietly areg eneur treated after_treated Iy* Ia* Ie* $individual_regressors, cl(pid) absorb(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table3.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, YES, Sociodemographic controls, YES) ctitle(All Workers) addstat(mean dep, `m')

** entrepreneurs only
keep if eneur_==1

quietly areg eneur treated after_treated Iy*, cl(pid) absorb(pid)  //Individual and time FE
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table3.doc, append keep(treated after*) addtext(Year FE, YES, Individual FE, YES, Age FE, NO, Years of education FE, NO, Sociodemographic controls, NO) ctitle(Entrepreneurs Only) addstat(mean dep, `m')

quietly areg eneur treated after_treated Iy* Ia* Ie* $individual_regressors, cl(pid) absorb(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table3.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, YES, Sociodemographic controls, YES) ctitle(Entrepreneurs Only) addstat(mean dep, `m')
erase $table/Table3.txt

****************************************************
** Table 4. Startups individuals, similar workers **
****************************************************
use temp2_prepared_fixed, clear

quietly areg eneur treated after_treated Iy* Ia* Ie* $individual_regressors if educ>=7 & educ<=8, absorb(pid) cl(pid)  //All FE (individual/time/age/degree), and time-varying individual characteristics, master and up
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table4.doc, replace keep(treated after* $individual_regressors) title(Table 4: Startups, Individual Level, Similar Workers) ctitle(Masters or more) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, YES, Sociodemographic controls, YES) addstat(mean dep, `m') addnote(The dependent variable is an indicator for whether the individual started a company that year. Estimates are the linear probability model, except in column [3] which compares Logit. Non-linear probability models [Probit or Logit] produce similar results in general but must be estimated without individual fixed effects. Column [1] restricts the sample to Norwegian workers with at least a master’s degree. All other specification restrict the sample to Norwegian workers with a least a Ph.D. The individual time-varying controls include lagged marital status, lagged total years of education dummies, log income, and log wealth. Propensity score matching predicts treatment status [university employment] using age fixed effects, detailed Ph.D. type fixed effects, gender, and marital status. Standard errors, in parentheses, are clustered by individual. *** p<0.01, ** p<0.05, * p<0.1.)

quietly areg eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, absorb(pid) cl(pid)  //All FE (individual/time/age/degree), and time-varying individual characteristics, master or more
quietly: summarize eneur if educ==8, d
local m =r(mean)
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) ctitle(Ph.D.) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) addstat(mean dep, `m')

quietly: summarize eneur if educ==8, d
local m =r(mean)
quietly logit eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, cl(pid)  //All FE (individual/time/age/degree), and time-varying individual characteristics, phds
quietly mfx
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Ph.D. Logit) mfx addstat(mean dep, `m')

*** Propensity score matching 
global rep "noreplacement" /* basic version: no replacement */
global neighbor "1"  /* basic version: neighbor "1" */
global calip "0.01" /* basic version: calip "0.05" */
global regressors "Ia* PP* sex married"  //PP is Phd type dummies

use temp4_prepared_fixed, clear
set seed 1234
tab treated
sort pid
probit treated $regressors i.yr 
predict pscore if e(sample), pr
gen pscore2=yr*10+pscore
sort pid
psmatch2 treated, neighbor($neighbor) pscore(pscore2) caliper($calip) $rep
pstest $regressors yr, mw(_weight) treated(_treated) summary
keep if _weight!=.
save matching, replace

use matching, clear  //add regression here
quietly reg eneur treated after_treated $individual_regressors PP* i.yr i.age if _weight!=. [fweight = _weight], cl(pid)
quietly: summarize eneur if _weight!=., d
local m =r(mean)
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, YES, Ph.D. Type FE, YES, Sociodemographic controls, YES) ctitle(Ph.D. Propensity Score Match) addstat(mean dep, `m')

** entrepreneurs only
use temp2_prepared_fixed, clear
keep if eneur_==1

quietly reg eneur treated after_treated Iy* if educ==8, cl(pid)    //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur if educ==8, d
local m =r(mean)
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, NO, Years of education FE, ., Sociodemographic controls, YES) ctitle(Ph.D. Entrepreneurs only) addstat(mean dep, `m')

quietly reg eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, cl(pid)
quietly: summarize eneur if educ==8, d
local m =r(mean)
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Ph.D. Entrepreneurs only) addstat(mean dep, `m')

** phd prior to 2000
use if yr_phd<2000 using temp4_prepared_fixed, clear
eststo: quietly areg eneur treated after after_treated Iy* Ia* $individual_regressors, cl(pid) absorb(pid)
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table4.doc, append keep(treated after* $individual_regressors) title(Individual FE, year of completed Ph.D.) ctitle(Ph.D. Earned pre 2000) dec(4) addnote(cluster at individual level) addstat(mean dep, `m') addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES)
erase $table/Table4.txt

*******************************************************
** Table 5. Stayers versus never (intensive margin) ***
*******************************************************
display "all, treated group 2, stayers"
use temp2_prepared_fixed, clear

** new code Sept 2015
drop stayer

* balance sample
bys pid: g obs = _N
keep if obs==8

* define stayers
bys pid: egen a = mean(treated)
g stayer=1 if a==1
g never=1 if a==0
keep if stayer==1 | never==1

eststo clear
quietly areg eneur treated after_treated Iy* Ia* Ie* $individual_regressors, absorb(pid) cl(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table5.doc, replace keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, YES, Sociodemographic controls, YES) ctitle(Stayers) title(Table 5: Startups, Individual Level, Intensive Margin) addstat(mean dep, `m') addnote(The dependent variable is an indicator for whether the individual started a company that year. Estimates are the linear probability model, except in columns [3] and [6], which uses Logit. Control group is either all Norwegian workers, columns [1] and [4], and Norwegian Ph.D. workforce in the other columns. The individual time-varying controls include lagged marital status, lagged total years of education dummies, log income, and log wealth. Standard errors, in parentheses, are clustered at individual level. *** p<0.01, ** p<0.05, * p<0.1.)

quietly areg eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, absorb(pid) cl(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur if educ==8, d
local m =r(mean)
outreg2 using $table/Table5.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Stayers, Ph.D.) addstat(mean dep, `m')

quietly: summarize eneur if educ==8, d
local m =r(mean)
logit eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, cl(pid)  //All FE (individual/time/age/degree), and time-varying individual characteristics, phds
quietly mfx
outreg2 using $table/Table5.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Stayers, Ph.D., Logit) mfx addstat(mean dep, `m')

** next columns have treated as uni workers prior to reform. control is never_uni=1. Have a balanced panel.

use temp2_prepared_fixed, clear

* balance sample
bys pid: g obs = _N
keep if obs==8

** define never (control group)
bys pid: egen a = mean(treated)
g never=1 if a==0

** redefine treated to those that work at uni all three years prior to reform
gen l=1 if treated==1 & yr==2000
replace l=1 if treated==1 & yr==2001
replace l=1 if treated==1 & yr==2002
bys pid: egen m=sum(l)
drop *treated*

gen treated=1 if m==3
replace treated=0 if never==1
gen after_treated=after*treated
keep if treated!=.

eststo clear
quietly areg eneur treated after_treated Iy* Ia* Ie* $individual_regressors, absorb(pid) cl(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur, d
local m =r(mean)
outreg2 using $table/Table5.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, YES, Sociodemographic controls, YES) ctitle(Stayers) title(Table 5: Startups, Individual Level, Intensive Margin) addstat(mean dep, `m') addnote(The dependent variable is an indicator for whether the individual started a company that year. Estimates are the linear probability model, except in columns [3] and [6], which uses Logit. Control group is either all Norwegian workers, columns [1] and [4], and Norwegian Ph.D. workforce in the other columns. The individual time-varying controls include lagged marital status, lagged total years of education dummies, log income, and log wealth. Standard errors, in parentheses, are clustered at individual level. *** p<0.01, ** p<0.05, * p<0.1.)

quietly areg eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, absorb(pid) cl(pid)   //All FE (individual/time/age/degree), and time-varying individual characteristics
quietly: summarize eneur if educ==8, d
local m =r(mean)
outreg2 using $table/Table5.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, YES, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Stayers, Ph.D.) addstat(mean dep, `m')

quietly: summarize eneur if educ==8, d
local m =r(mean)
logit eneur treated after_treated Iy* Ia* $individual_regressors if educ==8, cl(pid)  //All FE (individual/time/age/degree), and time-varying individual characteristics, phds
quietly mfx
outreg2 using $table/Table5.doc, append keep(treated after* $individual_regressors) addtext(Year FE, YES, Individual FE, NO, Age FE, YES, Years of education FE, ., Sociodemographic controls, YES) ctitle(Stayers, Ph.D., Logit) mfx addstat(mean dep, `m')
erase $table/Table5.txt

******************************************
** Globals for performance analysis ******
******************************************
global vars "stiftetorgnr yr stiftaar etableri faar naceSSB nace2 sumaksje employees"
global socio "age sex mstat"
global stats_ext "mean sd p50 p75 p90 p95 min max N"
global stats "mean sd p50 p75 p90 p95 N"

global cut_low "2000"
global cut_high "2007"
global individual_regressors = "married logbrform logpearn sex"

*****************************
*** Table 6A. Performance  **
*****************************
global performance_reg "logsales logemployees logassets"

use survive4 yr faar In* Iy* sample stiftaar firmage after* treated* stiftetorgnr if yr==faar using performance_panel_prepared_fixed, clear
quietly reg survive4 after after_treated treated Iy* In* if (sample==0|sample==2) & stiftaar!=1999, cl(stiftetorgnr)
outreg2 using $table/Table6A.doc, replace keep(treated after*) title(Table 6A: Startup Performance at Year 5) ctitle(Survive) dec(4) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Norway) addnote(Dependent variables are indicated at top of each column and indicate performance at year 5 after the founding year.  Firms all founded 2000-2007, and performance data is then 2005-2012.  Robust standard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.1.)

** All startups in Norway as control Year and 2-sector (original) controls, end of fifth year of operations
use $performance_reg In* Iy* sample stiftaar firmage after* treated* stiftetorgnr if firmage==4 using performance_panel_prepared_fixed, clear

foreach v of global performance_reg {
eststo: quietly reg `v' after after_treated treated Iy* In* if (sample==0|sample==2) & stiftaar!=1999, cl(stiftetorgnr)
outreg2 using $table/Table6A.doc, append keep(treated after*) title(Startup Performance at Year 5) ctitle(`v') dec(4) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Norway) 
}

use survive4 yr faar In* Iy* sample stiftaar firmage after* treated* stiftetorgnr if firmage==4 using performance_panel_prepared_fixed, clear
quietly reg survive4 after after_treated treated Iy* In* if firmage==4 & (sample==0|sample==4) & stiftaar!=1999, cl(stiftetorgnr)
outreg2 using $table/Table6A.doc, append keep(treated after*) title(Startup Performance at Year 5) ctitle(Survive) dec(4) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Ph.D.)

** Non-uni Phd startups as control
use $performance_reg In* Iy* sample stiftaar firmage after* treated* stiftetorgnr if firmage==4 using performance_panel_prepared_fixed, clear
foreach v of global performance_reg {
eststo: quietly reg `v' after after_treated treated Iy* In* if (sample==0|sample==4) & stiftaar!=1999, cl(stiftetorgnr)
outreg2 using $table/Table6A.doc, append keep(treated after*) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Non-Uni Ph.D.) ctitle(`v') dec(4) 
}
erase $table/Table6A.txt

**************************************************************************
** Table 6B. Performance, whether reach 75th (defined for all startups) **
**************************************************************************
global performance="salgsinn employees sumeiend"
capture erase $table/Table6B.txt
capture erase $table/Table6B.doc

** find 75 percentile for all startups, keep as local
use if sample==2 & firmage==4 using performance_panel_prepared_fixed, clear  //all startups Norway

foreach v of global performance {
replace `v'=0 if `v'==.               //NB: THIS IS HOW WE KEEP NON-SURVIVORS
quietly: summarize `v', d
local `v'_75 =r(p75)
}

foreach v of global performance {
display("`v'_75")
display(``v'_75')
}

** Create dummies
use if sample==0|sample==4|sample==2 using performance_panel_prepared_fixed, clear
keep if firmage==4

* drop some dummies
drop Iff*

foreach v of global performance {
replace `v'=0 if `v'==.               //NB: THIS IS HOW WE KEEP NON-SURVIVORS
gen dummy75_`v'=0
replace dummy75_`v'=1 if `v'>``v'_75'
}

** 75 percentile dummies analysis
capture erase $table/Table6B.txt

foreach v of global performance {
eststo: reg dummy75_`v' after after_treated treated Iy* In* if stiftaar!=1999 & (sample==0|sample==2), r
quietly: summarize dummy75_`v' if stiftaar!=1999 & (sample==0|sample==2), d
local m =r(mean)
outreg2 using $table/Table6B.doc, append keep(treated after*) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Norway) ctitle(`v') dec(4) addstat(mean dep, `m') title(Table 6B: Probability of Achieving 75th Percentile Performance at Year 5) addnote(Dependent variables are binary indicators for achieving at least the 75th percentile of performance in the indicated measure, where the 75th percentile is defined for Norwegian startups as a whole. Robust standard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.1.)
}

foreach v of global performance {
eststo: reg dummy75_`v' after after_treated treated Iy* In* if stiftaar!=1999 & (sample==0|sample==4), r
quietly: summarize dummy75_`v' if stiftaar!=1999 & (sample==0|sample==2), d
local m =r(mean)
outreg2 using $table/Table6B.doc, append keep(treated after*) addtext(Year FE, YES, 2-sector industry FE, YES, Control Sample, Non-Uni Ph.D.) ctitle(`v') dec(4) addstat(mean dep, `m')
}

erase $table/Table6B.txt

*******************************
** Table 6C. Startup sectors **
*******************************
use yearly_fixed, clear
capture erase $table/Table6C.txt
capture erase $table/Table6C.doc

eststo: quietly reg log_startups_tech after* treated if (sample==0|sample==2) & stiftaar!=1999, r
outreg2 using $table/Table6C.doc, replace keep(treated after*) title(Table 6C: Start-up Sectors) ctitle(Log Startups) addtext(Control Sample, Norway,  Startup Type, Higher Tech) addnote(Dependent variables are log of start-up counts for the indicated startup-type in the last row of table. Robust standard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.1.) 
eststo: quietly reg log_startups_tech after* treated if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table6C.doc, append keep(treated after*) addtext(Control Sample, Non-Uni Ph.D., Startup Type, Higher Tech) ctitle(Log Startups)
eststo: quietly reg log_startups_tech_noIT after* treated if (sample==0|sample==2) & stiftaar!=1999, r
outreg2 using $table/Table6C.doc, append keep(treated after*) addtext(Control Sample, Norway,  Startup Type, Higher Tech No ICT) ctitle(Log Startups)
eststo: quietly reg log_startups_tech_noIT after* treated if (sample==0|sample==4) & stiftaar!=1999, r
outreg2 using $table/Table6C.doc, append keep(treated after*) addtext(Control Sample, Non-Uni Ph.D.,  Startup Type, Higher Tech No ICT) ctitle(Log Startups)

erase $table/Table6C.txt
