/* This file generates alternative control group panels of workers

Input: adssb't', Ligning't', Foretaksinfo
Output: 'c'_worker_panel: one file for treated and for each control group */

******************
** Globals *******
******************
global root /home1/hans/Eship/Scientists
global data $root/data
global prepared $root/Prepared

global start "1995"
global stop "2010"
global socio_vars "pid yr plant org nace5 komres komarb edu* age pearn sex hrs mstat occ"
global wealth_vars "brform wkapin rentutg gjeld rentin brin"
global emp_vars "navn kommune"
global age_interval "age>=25 & age<=67"

** this set of globals is for ->2009 (c0 means treated group, c1-> are control groups)
global c0 keep if hrs==3 & educ==8 & (nace5==80301 | nace5==80302)  //main treated group
global c1 keep if hrs==3 & educ==8 & nace5==80301  //only unis, alternative treated group
global c2 keep if nace5!=80301 & nace5!=80302  // everyone not working at a uni/college, including part-time workers
global c3 keep if educ>=7 & educ<=8 & nace5!=80301 & nace5!=80302 //master or more not working at a uni, educ=7 is master/hovedfag/magister
global c4 keep if educ==8 & nace5!=80301 & nace5!=80302 //phds not working at a uni/college
global c5 keep if educ==8 & nace2==73 // all research institutes, phds, - does not make much sense as control group but ok as reference group
global c6 keep if educ==8 & nace3==731 // science and medicine research institutes, phds - does not make much sense as control group but ok as reference group
global c7 keep if educ>=7 & educ<=8 & nace2==73 // all research institutes - master level and up
global c8 keep if hrs==3 & educ==8 & private==1 //private unis phds
global c9 keep if hrs==3 & educ>=7 & educ<=8 & private==1 //private unis, master and up
global workers " "$c0" "$c1" "$c2" "$c3" "$c4" "$c5" "$c6" "$c7" "$c8" "$c9""

** this set of globals is for 2010 
global c10 keep if hrs==3 & educ==8 & (nace5==85421 | nace5==85422 | nace5==85423) //The three nace codes are for unis, vitenskapelige h�yskoler and statlige h�yskoler, see See http://stabas.ssb.no/ItemsFrames.asp?ID=8118001&Language=nb 
global c11 keep if hrs==3 & educ==8 & nace5==85421 
global c12 keep if nace5!=85421 & nace5!=85422 & nace5!=85423 // everyone not working at a uni
global c13 keep if educ>=7 & educ<=8 & nace5!=85421 & nace5!=85422 & nace5!=85423 // everyone full-time employed with a phd not working at a uni
global c14 keep if educ==8 & nace5!=85421 & nace5!=85422 & nace5!=85423 // everyone full-time employed with a phd not working at a uni
global c15 keep if educ==8 & nace2==72 // all research institutes, phds
global c16 keep if educ==8 & nace3==721 // science and medicine oriented research institutes, phds
global c17 keep if educ>=7 & educ<=8 & nace2==72 // all research institutes, master level and up
global c18 keep if hrs==3 & educ==8 & private==1 //private unis phds
global c19 keep if hrs==3 & educ>=7 & educ<=8 & private==1 //private unis, master and up
global workers2010 ""$c10" "$c11" "$c12" "$c13" "$c14" "$c15" "$c16" "$c17" "$c18" "$c19""

global loop "9"  //number of files to add up at end. NB: IF CHANGE THEN ALSO CHANGE IN JOINT.DO FILE!!

cd $root/Prepared

**********************************************
** Ia. Prepare lagged income, wealth file ****
**********************************************

** Lagged income, wealth and employer
forvalues t=$start/$stop {
local tminus=`t'-1
use $socio_vars if pid!=. using ${REG_DIR}adssb`tminus'.dta, clear
keep pid pearn plant hrs org
rename pearn pearn_l1
rename plant plant_l1
rename org org_l1
rename hrs hrs_l1

if `t'<=2007 {
sort pid
merge pid using "/home1/hans/data/inntdta/Ligning`tminus'.dta", nokeep keep(brform brin)
tab _merge
drop _merge
rename brform brform_l1
rename brin brin_l1
}

duplicates drop pid, force
sort pid
save socio_lagged`t', replace
}

**************************
** Ia. Initial sampling **  //includes both uni and control groups
**************************
forvalues t=$start/$stop {
use $socio_vars if pid!=. using ${REG_DIR}adssb`t'.dta, clear

** (i)keeping if prime work age
keep if $age_interval

gen nace2=int(nace5/1000)
gen nace3=int(nace5/100)
gen nace4=int(nace5/10)

** (ii)define educ (educ==8 includes a handful of licensiat degree holders)
if `t'<1999 {
gen educ=int(edut89/100000)
gen educ2=int(edut89/10000)
drop edut00*
}

if `t'>=1999 & `t'<=2006 {
gen educ=int(edut00/100000)
gen educ2=int(edut00/10000)
drop edut89 edut00_new
}

if `t'>=2007 {
gen educ=int(edut00_new/100000)
gen educ2=int(edut00_new/10000)
drop edut89 edut00
}

tab educ, m
tab educ2, m

*******************************
*** Ib. Import some variables *
*******************************
** wealth variables
if `t'<=2006 {
sort pid
merge pid using "/home1/hans/data/inntdta/Ligning`t'.dta", nokeep keep($wealth_vars)
tab _merge
drop _merge
}

** lagged socio variables
sort pid
merge pid using socio_lagged`t', nokeep
erase socio_lagged`t'.dta
tab _merge
drop _merge

save temp, replace

rename org orgnr
format %12.0g orgnr
rename yr aar
sort orgnr aar
merge orgnr aar using "/home1/hans/data/db/Foretaksinfo_0616.dta", nokeep keep($emp_vars)
tab _merge
drop _merge
rename navn emp_name
rename kommune emp_kommune
rename aar yr
*tab emp_name, missing

save nacetemp`t', replace  //One row per individual-year, all individuals. Now ready to define treated + x control groups
}

*************************************************
** II. Workers: first uni then control groups ***  //four different versions of control group
*************************************************
** for years up to 2009
local c=-1  //this is a counter which is handy when saving files below
foreach v of global workers {
local c `++c'  //counter adds 1

forvalues t=$start/2009 {
use nacetemp`t', clear //all workers
display "`v'"
`v'  // this drops the workers we are not interested in
count
sort pid
saveold `c'_workers_`t', replace
}
}

** for 2010 (different nace codes)
local c=-1  //this is a counter which is handy when saving files below
foreach v of global workers2010 {
local c `++c'  //counter adds 1, should be consistent with counter above

forvalues t=2010/$stop {
use nacetemp`t', clear 
display "`v'"
`v'  // this drops the workers we are not interested in
count
sort pid
saveold `c'_workers_`t', replace
}
}

forvalues c=0/$loop {
clear all
forvalues t=$start/$stop {
append using `c'_workers_`t'
erase `c'_workers_`t'.dta
}

drop nace3-nace4
duplicates drop pid yr, force  //drop duplicates (should be none)
compress
sum
bys yr: egen no_workers_yearly=count(pid)
saveold `c'_worker_panel, replace
}

**************************************************************************
**** IIa. Construct Phd_yr variable. NB do NOT drop if Phd prior to 2000 *
**************************************************************************
forvalues c=0/$loop {
use `c'_worker_panel, clear

bys pid: egen tenure=count(pid)
bys pid: egen entry_yr=min(yr)  //first year with that education level

gen graduation_yr=year(edudt)   //graduation year from register. NB: for -> 2009 the code is 15nov1970 while for 2010 it is 197011 and variable name different.
replace graduation_yr=int(edudt00_ssb/100) if yr==2010 //edudt is nonexisting for 2010 adssb file
gen Phd_yr=graduation_yr if educ==8

tab Phd_yr, m

//seems to be a lag between graduation year (yr_phd based on edudt) and year that enters temp files 
//therefore use entry_yr-1 as imputation for Phd year when missing (only 3% of cases). These cases may have gotten phd earlier but not later

** impute Phd_yr for educ==8 individuals
replace Phd_yr=entry_yr-1 if Phd_yr==. & educ==8  //only about 3% of phds. entry_yr=first year (minimum 1995) enter that workergroup.
tab Phd_yr, m

** keep only if Phd prior to 2000
*drop if Phd_yr>1999 & Phd_yr!=.
saveold `c'_worker_panel, replace
}

***************************************************************************
** III. Fix some misclassification (and make consistent with NIFU files) **
***************************************************************************

** find private university employees and add to other worker panels
use 0_worker_panel, clear
keep if orgnr==971523425 //** FORSVARETS FORSKNINGSINSTITUTT
save FF_worker_panel, replace

** remove private university and FF employees from treated group panels
forvalues c=0/1 {
use `c'_worker_panel, clear
drop no_workers_yearly
drop if private==1 | orgnr==971523425 //private unis + FORSVARETS FORSKNINGSINSTITUTT
duplicates drop pid yr, force
bys yr: egen no_workers_yearly=count(pid)
saveold `c'_worker_panel, replace
}

** append private uni workers to control groups
foreach c of numlist 2 3 {
use `c'_worker_panel, clear
append using 9_worker_panel  //append private unis master and up
duplicates drop pid yr, force
drop no_workers_yearly
bys yr: egen no_workers_yearly=count(pid)
saveold `c'_worker_panel, replace
}

** append private uni workers to control groups
foreach c of numlist 4 {
use `c'_worker_panel, clear
append using 8_worker_panel  //append private uni phds
duplicates drop pid yr, force
drop no_workers_yearly
bys yr: egen no_workers_yearly=count(pid)
saveold `c'_worker_panel, replace
}

foreach c of numlist 5 6 7 {
use `c'_worker_panel, clear
append using FF_worker_panel
duplicates drop pid yr, force
drop no_workers_yearly
bys yr: egen no_workers_yearly=count(pid)
saveold `c'_worker_panel, replace
}

** this set of globals is for ->2009 (c0 means treated group, c1-> are control groups)
global c0 keep if hrs==3 & educ==8 & (nace5==80301 | nace5==80302)  //main treated group
global c1 keep if hrs==3 & educ==8 & nace5==80301  //only unis, alternative treated group
global c2 keep if nace5!=80301 & nace5!=80302  // everyone not working at a uni/college, including part-time workers
global c3 keep if educ>=7 & educ<=8 & nace5!=80301 & nace5!=80302 //master or more not working at a uni, educ=6 is master, educ=7 is hovedfag and magister
global c4 keep if educ==8 & nace5!=80301 & nace5!=80302 //phds not working at a uni/college
global c5 keep if educ==8 & nace2==73 // all research institutes, phds, - does not make much sense as control group but ok as reference group
global c6 keep if educ==8 & nace3==731 // science and medicine research institutes, phds - does not make much sense as control group but ok as reference group
global c7 keep if educ>=7 & educ<=8 & nace2==73 // all research institutes - master level and up
global c8 keep if hrs==3 & educ==8 & private==1 //private unis phds
global c9 keep if hrs==3 & educ>=7 & educ<=8 & private==1 //private unis, master and up
global workers " "$c0" "$c1" "$c2" "$c3" "$c4" "$c5" "$c6" "$c7" "$c8" "$c9""

clear all
set obs 1
gen sample=.
forvalues c=0/$loop {
append using `c'_worker_panel
replace sample=`c' if sample==.
}
drop if pid==.
rename nace5 nace5_worker
rename nace2 nace2_worker
compress
saveold worker_panel_fixed, replace


