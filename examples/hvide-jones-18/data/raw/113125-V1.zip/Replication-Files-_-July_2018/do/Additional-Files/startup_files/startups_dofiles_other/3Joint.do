/* This file prepares lists of startups for different worker groups, aggregate numbers file, science_yearly.dta (#startups yearly for each worker group), 
and individual panel files

Input: founders.dta + Worker panels

Output: startups_workergroup_`v', science_yearly.dta, ind_panel'v', temp'v'_fixed, temp2_fixed_phdonly */

clear all

*****************
** Globals ******
*****************
global root "/home1/hans/Eship/Scientists"
global prepared "$root/Prepared"
global individual_regressors = "married logbrform* logpearn*"
global keep_variables "pid plant orgnr nace5 uni_name emp* age sex komres komarb $individual_regressors edu* hrs* eneur* treated after* share I* stayer tenure yr entry_yr"  //keep this in file where run regressions
global cut_low "2000"
global cut_high "2007"

global loop "9" //this is the number of treated + control groups, should equal the $loop in worker do-file. Norway as a whole has $loop+1.

cd $prepared
set niceness 0

*************************************
*** Ia. Startups per worker group  **
*************************************
** startups across treated and control groups
forvalues v=0/$loop {
use founders, clear  //one row per stiftetorgnr-founder
rename stiftaar yr 
sort pid yr

** one row per stiftetorgnr-founder for workers in 'v'_worker_panel 
joinby pid yr using `v'_worker_panel
rename yr stiftaar
saveold startups_workergroup_`v', replace  //one row per startup
}

********************************************************************
*** Ib. Startups per worker group, year after and two years after **
********************************************************************
local over "0 2 4 5 6 7"  //0=uni and college, 1=uni, 2==everyone full-time employed not working at a uni, 3=same as 2 but with at least master, 4=same as 2 but Phd, 6=all startups in norway  99=family members

** startups across treated and control groups, lag1
foreach v of local over {
use founders, clear  //one row per stiftetorgnr-founder
rename stiftaar yr 

** work year before 
if `v'!=0 {
replace yr=yr-1  //employed the year before for other than uni group!!
}

sort pid yr

** one row per stiftetorgnr-founder for workers in 'v'_worker_panel 
joinby pid yr using `v'_worker_panel

** get correct year for when firm started up
if `v'!=0 {
replace yr=yr+1  //employed the year before for other than uni group!!
}

rename yr stiftaar
gen nb="employed in workergroup'v' in yr-1"
sort stiftetorgnr pid stiftaar
saveold startups_lag1workergroup_`v', replace  //one row per startup
}

** startups across treated and control groups, lag2
foreach v of local over {
use founders, clear  //one row per stiftetorgnr-founder
rename stiftaar yr

if `v'!=0 {
replace yr=yr-2  //employed two years before for other than uni group!!
}

sort pid yr

** one row per stiftetorgnr-founder for workers in 'v'_worker_panel 
joinby pid yr using `v'_worker_panel

** get correct year for when firm started up
if `v'!=0 {
replace yr=yr+2  //employed the year before for other than uni group!!
}

rename yr stiftaar
gen nb="employed in workergroup'v' in yr-2"
sort stiftetorgnr pid stiftaar
saveold startups_lag2workergroup_`v', replace  //one row per startup
}

local over "0 2 4 5 6 7"  //0=uni and college, 1=uni, 2==everyone full-time employed not working at a uni, 3=same as 2 but with at least master, 4=same as 2 but Phd, 6=all startups in norway  99=family members
global list "lag1 lag2"
** science_yearlylag1.dta and science_yearly_lag2.dta
foreach m of global list {
foreach v of local over {
use stiftetorgnr stiftaar using startups_`m'workergroup_`v', clear
duplicates drop stiftetorgnr, force
bys stiftaar: egen no_startups_yearly=count(stiftetorgnr)
display "number of startups in total for that group of workers"
count
duplicates drop stiftaar, force
gen sample=`v'
keep stiftaar no_startups_yearly sample
save science_yearly_`m'_`v', replace  //one row per startup
}

clear all
foreach v of local over {
append using science_yearly_`m'_`v'
erase science_yearly_`m'_`v'.dta
}

sort stiftaar sample
saveold science_yearly_`m', replace  //one row per year, counts no of startups per group
}

** Aggregate regressions: treated versus worker groups and all Norway startups
global list "lag1 lag2"
local over "0 2 4 5 6 7" 
foreach m of global list {
use science_yearly_`m', clear //remember sample==99 is family members of uni workers!

** before, after, treated
gen after=stiftaar>=2003
gen treated=sample==0
gen after_treated=after*treated
set linesize 255
gen log_startups=ln(no_startups_yearly)

eststo clear
foreach v of local over {

if `v'!=0 {  //no point in regressing treatment group against itself
eststo: quietly reg log after* treated if sample==0|sample==`v'
}
}
esttab, ar2 star(* 0.10 ** 0.05 *** 0.01) title(aggregate analysis, log number of startups yearly, lag1 first then lag2) mtitles(not_uni_college phd 73_phd 731_phd 73_master)
}

****************************
** II. science_yearly.dta **
****************************
** 1. Counting startups yearly, per workergroup
forvalues v=0/$loop {
use stiftetorgnr stiftaar using startups_workergroup_`v', clear
duplicates drop stiftetorgnr, force
bys stiftaar: egen no_startups_yearly=count(stiftetorgnr)
display "number of startups in total for that group of workers"
count
duplicates drop stiftaar, force
gen sample=`v'
keep stiftaar no_startups_yearly sample
save science_yearly_`v', replace  //one row per startup
}

** yearly startups Norway (here do not use a particular set of workers but include ALL startups in Norway with at least one personal owner)
use founders, clear  //one row per stiftetorgnr-founder
bys stiftaar: egen no_startups_yearly=count(stiftetorgnr)
display "number of startups in total for that group of workers"
count
duplicates drop stiftaar, force
local c=$loop+1
gen sample=`c'
gen sample_name="all"
keep stiftaar no_startups_yearly sample
saveold science_yearly_`c', replace  //one row per year

clear all
forvalues v=0/`c' {
append using science_yearly_`v'
erase science_yearly_`v'.dta
}

sort stiftaar sample
saveold science_yearly_fixed, replace  //one row per year, counts no of startups per group

************************************************************************
** III. Create panels of individuals, incl info about startup activity *
************************************************************************

foreach t of numlist 0, 2/9 {    //treated and various control groups
use `t'_worker_panel, clear  //one obs per worker-yr
rename yr stiftaar
keep if stiftaar>=$cut_low & stiftaar<=$cut_high  //these is time interval where we observe startup activity

sort pid stiftaar
merge pid stiftaar using startups_workergroup_`t', keep(stiftetorgnr share nace5_startup) nokeep  //NBNBNNBB: not 1-1 merge, could be more than one startup per individual-year
tab _merge
drop _merge
rename stiftaar yr

** firm variables
gen nace2_startup=int(nace5_startup/1000)

gen n5=nace5_startup
gen n4=int(n5/10)
gen n3=int(n5/100)
gen n2=int(n5/1000)

** hi tech
gen hi_tech=(n3==244|n2==30|n2==32|n2==33|n3==353)

** medium to high tech
gen medium_hi_tech=(n2==29|n2==31|n2==34)
replace medium_hi_tech=1 if n2==24 & n3!=244
replace medium_hi_tech=1 if n2==35 & n3!=351 & n3!=353

** medium to low tech. NB here we add oil and gas nace 11!!!!
gen medium_lo_tech=(n3>=23&n3<=28) & n3!=24 //nace==11, oil and gas, 23 coke refined petroleum,  24 chemicals, 27 metals, 28 mechanical, 29 machinery, 30 office equip and computers, 31 electrical, 32 radio television communication, 33 medical instruments,  34 motor vehicles, 72 IT
replace medium_lo_tech=1 if n2==11

** hi_tech knowledge intensive
replace hi_tech=1 if n2==64|n2==72|n2==73

/* DROP hi knowledge intensive industries
gen kis=(n2>=61&n2<=67) & n2!= 63
replace kis=1 if n2==62|n2==64 */

** low tech
gen lo_tech=0
replace lo_tech=1 if hi_tech==0 & medium_hi_tech==0 & medium_lo_tech==0

** broad tech category
gen tech=0
replace tech=1 if lo_tech==0

** broad tech without IT
gen tech_noIT=tech
replace tech_noIT=0 if n2==72

** eneur variables
gen e=stiftetorgnr!=.  //starts up a firm in that year
bys yr pid: egen eneur=max(e)
drop e 
gen eneur_big=share>=.5 & share<. //dominant founder
gen eneur_hi_tech=(eneur==1&hi_tech==1)
gen eneur_tech=(eneur==1&tech==1)
gen eneur_tech_noIT=(eneur==1&tech_noIT==1)
gen eneur_lo_tech=(eneur==1&lo_tech==1)

drop n2 n3 n4 n5

duplicates drop pid yr, force //NBNBNB keep one row per individual. 

** individual level variables
*tab nace5 
tab tenure
sort pid yr
replace brform=brform_l1 if brform_l1!=.
replace pearn=pearn_l1 if pearn_l1!=.
drop pearn_* brform_*
gen agesq=age^2
gen logpearn=ln(pearn+1000)
gen logbrform=ln(brform+1000)
gen logint=logpearn*logbrform
gen female=sex==2
gen married=mstat==2

** stayers (require at least one obs before and one after in the same group)
bys pid: egen min=min(yr)
bys pid: egen max=max(yr)
gen stayer=0
replace stayer=1 if min<2003 & max>=2003 & max!=.
tab stayer, m

display "fill in years where NOT in this group"
fillin pid yr
drop if yr<min | yr>max
drop min max
tab _fillin
gen employed=_fillin==0  //whether employed by uni or not that year

saveold ind_panel_`t', replace
}

*************************
** V. Prepare DiD files *
*************************

** Difference-in-difference, various control groups
forvalues t=2/9 {    //various control groups
use ind_panel_0, clear  //treated group	
gen treated=1
append using ind_panel_`t'
replace treated=0 if treated==.
keep if employed==1  //only keep if in group that year
drop employed

gen logpearnsq=logpearn^2
gen logbrformsq=logbrform^2

gen after=yr>=2003
gen after_treated=treated*after
tab treated, missing

** year age and degree dummies
xi i.yr, noomit
renpfix _I I
xi i.age, noomit
renpfix _I I
xi i.educ, noomit
renpfix _I I

** eneur_
bys pid: egen eneur_=max(eneur)  //starts up at least once

** eneur_before
gen l=yr<=2002 
gen e=l*eneur
bys pid: egen eneur_before=max(e)
drop l e

saveold temp`t'_fixed, replace
}

use temp2_fixed, clear
keep if educ==8
save temp2_fixed_phdonly, replace

